<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'blog' );

/** MySQL database username */
define( 'DB_USER', 'bloguser' );

/** MySQL database password */
define( 'DB_PASSWORD', 'blog123@@' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

define('FS_METHOD', 'direct');
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '@-y474<V=@@w7TsB K9-BD6c&5X8evVr8C0aT;#bh>G8QPEaL>p+zRfQuwJunkb8');
define('SECURE_AUTH_KEY',  'u%ZkR&%q&e?MT_?dcpH{g;4]%=io/|+*9X<#*_q]1<fp{Kj2?K<fMqQsW:-bnbgM');
define('LOGGED_IN_KEY',    'XQ9@6wZTg+?&1rFuK,1VQ).8unQ}e9Av~g(IRK[~Q%hHjh;]Emvt|EbxgstWjx|A');
define('NONCE_KEY',        'u5_/${y<kEv|oCD5bFMZ?sJ4L88}a3+OyH5?+kyP?R`M]*_pbKi8Ev9$gOl8HbO(');
define('AUTH_SALT',        'F/e$e`1vN|OESsLo3-{KOkDn)]K{4+sJgqzYFft:$5!F+eCZ].&gE9]rW}D+`pI)');
define('SECURE_AUTH_SALT', 'uJ0#>DX>f65a/[d?EM`ABP<yGx;M|rQ4R5xHx{77~i7h7Q1o+<=&BM1HyU|Z#!aA');
define('LOGGED_IN_SALT',   'nsD/|:&tul9y4Wit)|I|*jA%|hA9+Wf3M jC>`Vf[d,-OO|P|U-MEW@?*A)wX+f4');
define('NONCE_SALT',       'G+_K]a2fJbe4de5:VU4pO7|ENl#/-WB 7Y,on~e3J0:b|(m#)hr=-290r&@,bYpE');


/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
    set_time_limit(300);
    
    define( 'WP_MAX_MEMORY_LIMIT', '256M' );
    define('WP_MEMORY_LIMIT', '256M');
    
    
    
define('CONCATENATE_SCRIPTS', false); 
if ($_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') $_SERVER['HTTPS']='on';
require_once( ABSPATH . 'wp-settings.php' );
